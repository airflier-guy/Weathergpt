// Free Telegram bot. Runs only if TELEGRAM_BOT_TOKEN is set in .env.
// It uses "long polling" (the bot asks Telegram for new messages), so it needs no public URL.
// It works while this app is running (e.g. on your computer during a demo).

import crypto from 'node:crypto';
import { reply } from './brain.js';
import { handleSubCommand, runChecks, startScheduler, storageKind } from './subs.js';

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
export let botUsername = null;
const API = `https://api.telegram.org/bot${TOKEN}`;

// Webhook mode: used automatically on a public host (Render sets RENDER_EXTERNAL_URL; you can also set PUBLIC_URL).
// Telegram then sends each message to /telegram/webhook, which wakes a sleeping free server.
// Polling mode: used on your own computer (no public address).
const PUBLIC_URL = (process.env.PUBLIC_URL || process.env.RENDER_EXTERNAL_URL || '').replace(/\/$/, '');
const WEBHOOK_MODE = Boolean(TOKEN && PUBLIC_URL && process.env.TELEGRAM_MODE !== 'polling');
const SECRET = TOKEN ? crypto.createHash('sha256').update('wg:' + TOKEN).digest('hex').slice(0, 40) : '';

const chats = new Map(); // chatId -> { lang, history }
const WELCOME = {
  en: "Hi! I'm WeatherGPT 🌦️\nAsk me for a forecast, weather alerts or climate info for any place, e.g. \"weather in Kolkata\" or \"alerts for Puri\".\nLanguage: /english  /hindi  /bengali\n🔔 Daily brief + alerts: /subscribe Puri farmer",
  hi: "नमस्ते! मैं WeatherGPT हूँ 🌦️\nकिसी भी स्थान का मौसम, चेतावनी या जलवायु पूछें, जैसे \"कोलकाता का मौसम\"।\nभाषा: /english  /hindi  /bengali\n🔔 रोज़ सारांश और चेतावनी: /subscribe Puri farmer",
  bn: "নমস্কার! আমি WeatherGPT 🌦️\nযেকোনো জায়গার আবহাওয়া, সতর্কতা বা জলবায়ু জিজ্ঞাসা করুন, যেমন \"কলকাতার আবহাওয়া\"।\nভাষা: /english  /hindi  /bengali\n🔔 প্রতিদিনের সারসংক্ষেপ ও সতর্কতা: /subscribe Puri farmer"
};
const LANGS = { '/english': 'en', '/hindi': 'hi', '/bengali': 'bn' };

async function tg(method, body) {
  const r = await fetch(`${API}/${method}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(45000) });
  return r.json();
}
export const sendTelegram = (chatId, text) => tg('sendMessage', { chat_id: chatId, text: plain(text) });
export const runAlertChecks = () => runChecks(sendTelegram);
const plain = s => s.replace(/\*\*/g, '').slice(0, 4000);

async function handle(msg) {
  const id = msg.chat.id, text = (msg.text || '').trim();
  if (!text) return;
  const st = chats.get(id) || { lang: 'en', history: [] };
  chats.set(id, st);

  const cmd = text.split(/\s|@/)[0].toLowerCase();
  if (cmd === '/start' || cmd === '/help') return tg('sendMessage', { chat_id: id, text: WELCOME[st.lang] });
  if (LANGS[cmd]) { st.lang = LANGS[cmd]; st.history = []; return tg('sendMessage', { chat_id: id, text: WELCOME[st.lang] }); }

  if (['/subscribe', '/unsubscribe', '/mysubs'].includes(cmd)) {
    const args = text.replace(/^\S+\s*/, '');
    return tg('sendMessage', { chat_id: id, text: await handleSubCommand(id, cmd, args, st.lang) }).catch(() => {});
  }

  tg('sendChatAction', { chat_id: id, action: 'typing' }).catch(() => {});
  st.history.push({ role: 'user', content: text });
  try {
    const out = await reply(st.history, st.lang);
    st.history.push({ role: 'assistant', content: out.reply });
    st.history = st.history.slice(-20);
    await tg('sendMessage', { chat_id: id, text: plain(out.reply) });
  } catch (e) {
    st.history.pop();
    console.error('telegram handler error:', e.message);
    await tg('sendMessage', { chat_id: id, text: 'Sorry, something went wrong. Please try again.' });
  }
}

// Call once before the server starts listening.
export function telegramRoutes(app) {
  if (!WEBHOOK_MODE) return;
  app.post('/telegram/webhook', (req, res) => {
    if (req.get('x-telegram-bot-api-secret-token') !== SECRET) return res.sendStatus(403);
    res.sendStatus(200); // answer Telegram at once; the reply is sent afterwards
    const msg = req.body?.message;
    if (msg) handle(msg).catch(e => console.error('telegram webhook error:', e.message));
  });
}

export async function startTelegram() {
  if (!TOKEN) { console.log('Telegram bot: not started (no TELEGRAM_BOT_TOKEN found).'); return; }
  const me = await tg('getMe', {}).catch(() => null);
  if (!me?.ok) { console.error('Telegram: token looks wrong (getMe failed). Bot not started.'); return; }
  botUsername = me.result.username;
  startScheduler(sendTelegram);
  console.log(`Subscriptions storage: ${storageKind}`);
  if (WEBHOOK_MODE) {
    const r = await tg('setWebhook', { url: `${PUBLIC_URL}/telegram/webhook`, secret_token: SECRET, allowed_updates: ['message'], drop_pending_updates: false });
    if (!r?.ok) { console.error('Telegram: could not set the webhook:', r?.description); return; }
    console.log(`Telegram bot running (webhook mode): https://t.me/${botUsername}`);
    return;
  }
  await tg('deleteWebhook', {}).catch(() => {});
  console.log(`Telegram bot running (on this computer): https://t.me/${botUsername}`);
  console.log('  Note: while this runs, an online copy using the same token will stop receiving messages.');

  let offset = 0;
  (async function loop() {
    for (;;) {
      try {
        const res = await tg('getUpdates', { offset, timeout: 30, allowed_updates: ['message'] });
        for (const u of res.result || []) { offset = u.update_id + 1; if (u.message) handle(u.message); }
      } catch (e) {
        console.error('Telegram polling error:', e.message);
        await new Promise(r => setTimeout(r, 5000));
      }
    }
  })();
}
